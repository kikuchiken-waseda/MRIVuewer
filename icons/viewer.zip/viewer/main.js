// target file
let mp4 = './10.mp4';
const fileApp = new Vue({
    el: '#filerApp',
    data: {
        results: []
    },
    mounted() {
        axios.get("http://localhost:8888/").then(
            response => {
                console.log(response.data.results);
                this.results = response.data.results;
            }
        )
    }
});


let videoApp = new Vue({
    el: '#videoApp',
    data: {
        frameRate: 13.87,
        time: 0,
        video: document.getElementById("video"),
        wavVideo: null,
        timelineOpts: {container: '#wave-timeline'},
        spectrogramOpts: {
            container: '#wave-spectrogram',
            labels: true,
        },
        options: {
            container: '#waveform',
            waveColor: 'red',
            progressColor: 'purple',
            loaderColor: 'purple',
            cursorColor: 'navy',
            plugins: [],
            height: 100,
            minPxPerSec: 200,
            scrollParent: true,
            normalize: true,
            mediaType: 'video',
        },
    },
});

let waveformApp = new Vue({
    el: '#waveformapp',
    data: {
        loading: false,
    },
});

let cardHeader = new Vue({
    el: '#cardHeader',
    data: {
        fname: videoApp.video.src,
    },
});


let infoapp = new Vue({
    el: '#info',
    data: {
        zoom: 1,
        now: videoApp.time,
        frame_n: Math.round(videoApp.time * videoApp.frameRate),
    },
});

let message = new Vue({
    el: '#message',
    data: {
        label: '',
    },
});

let messages = new Vue({
    el: '#messages',
    data: {
        messages: [],
    },
});


function init_video(fname) {
    let WaveSurfer = window.WaveSurfer;
    let TimelinePlugin = WaveSurfer.timeline;
    let SpectrogramPlugin = WaveSurfer.spectrogram;

    videoApp.options.plugins.push(
        SpectrogramPlugin.create(
            videoApp.spectrogramOpts
        )
    );
    videoApp.options.plugins.push(
        TimelinePlugin.create(
            videoApp.timelineOpts
        )
    );
    videoApp.video.src = fname;
    videoApp.video.volume = 0;
    videoApp.wavVideo = WaveSurfer.create(videoApp.options);
    videoApp.wavVideo.load(videoApp.video.src);
    console.log(videoApp.wavVideo.backend.ac.sampleRate);

    videoApp.wavVideo.on('loading', function() {
        waveformApp.loading = true;
    });

    videoApp.wavVideo.on('ready', function() {
        waveformApp.loading = false;
    });

    videoApp.wavVideo.on('seek', function() {
        videoApp.time = videoApp.wavVideo.getCurrentTime();
        infoapp.now = videoApp.time;
        infoapp.frame_n = Math.round(videoApp.time * videoApp.frameRate);
        videoApp.video.currentTime = videoApp.time;
    });
};


function playVideo() {
    videoApp.time = videoApp.wavVideo.getCurrentTime();
    videoApp.video.currentTime = videoApp.time;
    infoapp.now = videoApp.time;
    infoapp.frame_n = Math.round(videoApp.time * videoApp.frameRate);
    videoApp.video.play();
    videoApp.wavVideo.play();
}

function zoom_in() {
    waveformApp.loading = true;
    infoapp.zoom = 200;
    videoApp.time = videoApp.wavVideo.zoom(infoapp.zoom);
    waveformApp.loading = false;
}

function zoom_out() {
    waveformApp.loading = true;
    infoapp.zoom = 1;
    videoApp.time = videoApp.wavVideo.zoom(infoapp.zoom);
    waveformApp.loading = false;
}

function stopVideo() {
    videoApp.time = videoApp.wavVideo.getCurrentTime();
    videoApp.video.currentTime = videoApp.time;
    infoapp.now = videoApp.time;
    infoapp.frame_n = Math.round(videoApp.time * videoApp.frameRate);
    videoApp.video.pause();
    videoApp.wavVideo.pause();
}


function addmessage() {
    messages.messages.push({
        time: infoapp.now,
        frame_n: infoapp.frame_n,
        label: message.label,
    });
    message.label = '';
}

function downloadMessages() {
    if (messages.messages.length > 0) {
        let csv_array = [];
        let header = [];
        let terget = messages.messages;

        // header を追記
        for (let k in terget[0]) header.push(k);
        csv_array.push(header);

        // body を追記
        terget.forEach(function(obj, i, a) {
            let temp_array = [];
            for (let k in obj) {
                temp_array.push(obj[k]);
            }
            csv_array.push(temp_array);
        });
        console.log(csv_array);

        // csv 化
        let csv_data = csv_array.map(function(l){return l.join(',')}).join('\r\n');
        let bom = new Uint8Array([0xEF, 0xBB, 0xBF]);
        let blob = new Blob([bom, csv_data], { type: 'text/csv' });

        // ダウンロード実行.
        let file_name = 'test.csv';
        if (window.navigator.msSaveOrOpenBlob) {
            // IEの場合
            navigator.msSaveBlob(blob, file_name);
        } else {
            // IE以外(Chrome, Firefox)
            let downloadLink = $('<a></a>');
            downloadLink.attr('href', window.URL.createObjectURL(blob));
            downloadLink.attr('download', file_name);
            downloadLink.attr('target', '_blank');
            $('body').append(downloadLink);
            downloadLink[0].click();
            downloadLink.remove();
        }
    }
};


init_video(mp4);

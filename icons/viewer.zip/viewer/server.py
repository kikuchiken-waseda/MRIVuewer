# -*- coding: utf-8 -*-

from tornado.web import RequestHandler, Application


def get_mp4s():
    from os import path
    from glob import glob
    rootdir = path.dirname(path.dirname(path.abspath(__file__)))
    datadir = path.join(rootdir, 'data')
    return {
        'results': glob(path.join(datadir, '*', '*', 'MP4', '*', '*.mp4'))
    }


class MainHandler(RequestHandler):
    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header("Access-Control-Allow-Headers", "x-requested-with")
        self.set_header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS')

    def get(self):
        from json import dumps
        mp4s = get_mp4s()
        self.write(dumps(mp4s))


def makeApp():
    return Application([
        (r"/", MainHandler),
    ])


if __name__ == "__main__":
    from tornado.ioloop import IOLoop
    app = makeApp()
    app.listen(8888)
    IOLoop.instance().start()
